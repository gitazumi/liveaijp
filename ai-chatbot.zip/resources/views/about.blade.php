<x-app-layout>
    <x-slot name="header">
            {{ __('About us') }}
    </x-slot>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 border-b border-gray-200">
            {{ __('Sample static text page') }}
        </div>
    </div>
</x-app-layout>
