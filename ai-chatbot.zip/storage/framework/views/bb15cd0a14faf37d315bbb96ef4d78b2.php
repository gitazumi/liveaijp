<?php echo e($slot); ?>

<?php /**PATH /home/sty1/public_html/ai-chatbot-backend/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>