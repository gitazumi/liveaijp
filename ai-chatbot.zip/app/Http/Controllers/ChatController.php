<?php

namespace App\Http\Controllers;

use App\Models\Chat;
use App\Models\Conversation;
use App\Models\Faq;
use App\Models\GoogleCalendar;
use App\Models\Information;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Google\Client;
use Google\Service\Calendar;

class ChatController extends Controller
{
    private $openai_api_key;
    private $model = 'gpt-4';
    private $max_tokens = 1000;
    private $temperature = 0.7;

    public function __construct()
    {
        $this->openai_api_key = "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";
        // $this->openai_api_key = env('OPENAI_API_KEY', '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');
    }

    /**
     * Get or create session ID for anonymous user
     */
    private function getSessionId()
    {
        if (!session()->has('chat_session_id')) {
            session(['chat_session_id' => Str::uuid()]);
        }
        return session('chat_session_id');
    }

    /**
     * Get chat history for current session
     */
    public function getChatHistory()
    {
        $sessionId = $this->getSessionId();
        $conversation = Conversation::where('session_id', $sessionId)->first();

        if (!$conversation) {
            return response()->json([
                'messages' => []
            ]);
        }

        $messages = Chat::where('conversation_id', $conversation->id)
            ->orderBy('created_at', 'asc')
            ->get()
            ->map(function ($chat) {
                return [
                    'message' => $chat->message,
                    'send_by' => $chat->send_by ? 'user' : 'ai',
                    'created_at' => $chat->created_at->format('Y-m-d H:i:s')
                ];
            });

        return response()->json([
            'messages' => $messages
        ]);
    }

    /**
     * Handle new message
     */
    public function message(Request $request)
    {
        try {
            if (Auth::id()) {
                $userId = Auth::id();    
            } else {
                $user = User::where('chatbot_token', $request->header('X-Chatbot-Token'))->first();
                if($user){
                    $userId = $user->id;
                }else{
                    return response()->json([
                        'error' => true,
                        'message' => 'Invalid chatbot token.'
                    ], 500);
                }
                if (!$userId) {
                    return response()->json([
                        'error' => true,
                        'response' => $request->header('X-Chatbot-Token')
                    ]);
                }              
            }
            if ($request->conversation_id) {
                $sessionId = $request->conversation_id;
            } else {
                $sessionId = $this->getSessionId();
            }
            $conversation = $this->getOrCreateConversation($sessionId, $request->message, $userId);
            // Store user message
            $this->storeMessage([
                'conversation_id' => $conversation->id,
                'message' => $request->message,
                'send_by' => 1
            ]);

            // Get context and AI response
            $contextMessages = $this->getConversationContext($conversation->id);
            $aiResponse = $this->getAiResponse($contextMessages, $userId);

            if (isset($aiResponse['error'])) {
                throw new \Exception($aiResponse['error']);
            }

            // Store AI response
            $this->storeMessage([
                'conversation_id' => $conversation->id,
                'message' => $aiResponse['message'],
                'openai_message_id' => $aiResponse['message_id'],
                'send_by' => 0
            ]);
            $processedResponse = $this->renderHyperlinks($aiResponse['message']);

            return response()->json([
                'error' => false,
                'response' => $processedResponse
            ]);
        } catch (\Exception $e) {
            Log::error('Chat Error: ' . $e->getMessage());
            return response()->json([
                'error' => true,
                'message' => 'An error occurred while processing your message.',
                'issue' => $e->getMessage()
            ], 500);
        }
    }
    private function renderHyperlinks($text)
    {
        // Regular expression to detect URLs
        $urlRegex = '/(https?:\/\/[^\s]+)/';
    
        // Replace URLs with HTML anchor tags
        return preg_replace_callback($urlRegex, function ($matches) {
            $url = $matches[0];
            return '<a href="' . $url . '" target="_blank" rel="noopener noreferrer">' . $url . '</a>';
        }, $text);
    }

    /**
     * Get or create conversation for session
     */
    private function getOrCreateConversation($sessionId, $title, $userId)
    {
        return Conversation::firstOrCreate(
            [
                'session_id' => $sessionId,
            ],
            ['title' => $title,'user_id' => $userId]
        );
    }

    private function storeMessage($data)
    {
        return Chat::create($data);
    }

    private function getConversationContext($conversationId, $limit = 10)
    {
        $recentMessages = Chat::where('conversation_id', $conversationId)
            ->orderBy('created_at', 'desc')
            ->limit($limit)
            ->get()
            ->reverse();

        $messages = [];
        foreach ($recentMessages as $message) {
            $messages[] = [
                'role' => $message->send_by ? 'user' : 'assistant',
                'content' => $message->message
            ];
        }

        return $messages;
    }

    private function getAiResponse($messages, $userId)
    {
        $url = "https://api.openai.com/v1/chat/completions";
                
        $storeInformation = Information::where('user_id', $userId)->first();
        $storeInformation = json_encode($storeInformation);
        $faqs = Faq::where('user_id', $userId)->get();
        $events = $this->getCalendarEvents($userId);
        $faqContent = $faqs->map(function ($faq) {
            return "- {$faq->question}: {$faq->answer}";
        })->join("\n");
        
   
        $events = json_encode($events);
        Log::error('events: ' . $events);
        Log::error('faqs: ' . $faqContent);
        Log::error('$userId: ' . $userId);
        $data = [
            "model" => $this->model,
            "messages" => array_merge(
                [
                    [
                        'role' => 'system',
                        'content' => "You are a chatbot trained to answer based on the following FAQs and Calendar Events:\n\nFAQs:\n$faqContent\n\nCalendar Events:\n$events\n\n. Answer questions as if you are their assistant. your company information: $storeInformation"
                    ]
                ],
                $messages // Append user and assistant messages
            ),
            "max_tokens" => $this->max_tokens,
            "temperature" => $this->temperature,
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json",
                "Authorization: Bearer {$this->openai_api_key}",
            ],
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_TIMEOUT => 3000,
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ['error' => $error];
        }

        $responseData = json_decode($response, true);
        if (isset($responseData['error'])) {
            return ['error' => $responseData['error']['message']];
        }

        return [
            'message' => $responseData['choices'][0]['message']['content'],
            'message_id' => $responseData['id']
        ];
    }

    public function getCalendarEvents($userId)
    {
        try {
            $user = User::find($userId);

            $client = new \Google_Client();
            $client->setAccessToken($user->google_access_token);

            if ($client->isAccessTokenExpired()) {
                $client->fetchAccessTokenWithRefreshToken($user->google_refresh_token);
                $user->update(['google_access_token' => $client->getAccessToken()['access_token']]);
            }

            $service = new Calendar($client);
            $calendarId = 'primary';
            $events = $service->events->listEvents($calendarId);
            return $events->getItems();
        } catch (\Exception $e) {
            return [];
        }
    }


    // public function getCalendarEvents($userId)
    // {
    //     try {
    //         $calendar = GoogleCalendar::where('user_id', $userId)->first();

    //         if (!$calendar || !$calendar->access_token) {
    //             return [];
    //         }

    //         $client = new Client();
    //         $client->setClientId($calendar->client_id);
    //         $client->setClientSecret($calendar->client_secret);
    //         $client->setAccessToken($calendar->access_token);

    //         if ($client->isAccessTokenExpired()) {
    //             if ($calendar->refresh_token) {
    //                 $newToken = $client->fetchAccessTokenWithRefreshToken($calendar->refresh_token);
    //                 $client->setAccessToken($newToken['access_token']);

    //                 $calendar->update([
    //                     'access_token' => $newToken['access_token'],
    //                     'refresh_token' => $newToken['refresh_token'] ?? $calendar->refresh_token,
    //                 ]);
    //             } else {
    //                 return [];
    //             }
    //         }

    //         $service = new \Google\Service\Calendar($client);
    //         $calendarId = $calendar->calendar_id ?? 'primary';
    //         $events = $service->events->listEvents($calendarId);

    //         return $events->getItems();
    //     } catch (\Exception $e) {
    //         return [];
    //     }
    // }

    function history()
    {
        $conversations = Conversation::where('user_id', Auth::id())->latest()->paginate(10);
        return view('admin.chat.history', compact('conversations'));
    }
    function chat($sessionId)
    {
        $chats = Conversation::with('messages')->where('session_id', $sessionId)->firstOrFail();
        return view('admin.chat.chat', compact('chats'));
    }
    function chatBot()
    {
        return view('admin.chat.bot');
    }

  
    function generateSnippet()
    {
        $user = User::find(Auth::id());
        if (!$user->chatbot_token) {
            $user->chatbot_token = Str::uuid()->toString();
            $user->save();
        }

        return view('admin.chat.snippet', compact('user'));
    }
}
