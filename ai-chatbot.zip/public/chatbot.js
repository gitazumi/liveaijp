(function() {
    class AIChatbot {
        constructor() {
            this.token = this.getTokenFromScript();
            this.conversationId = 'conv_' + Math.random().toString(36).substr(2, 9);
            this.apiEndpoint = 'https://sty1.devmail-sty.online/ai-chatbot-backend/public/api/chat';
            this.init();
        }

        getTokenFromScript() {
            const scripts = document.getElementsByTagName('script');
            const currentScript = scripts[scripts.length - 1];
            const url = new URL(currentScript.src);
            return url.searchParams.get('token');
        }

        init() {
            this.injectMetaTag();
            this.injectStyles();
            this.createWidget();
            this.addEventListeners();
        }

        injectMetaTag() {
            if (!document.querySelector('meta[name="viewport"]')) {
                const meta = document.createElement('meta');
                meta.name = 'viewport';
                meta.content = 'width=device-width, initial-scale=1, maximum-scale=1';
                document.head.appendChild(meta);
            }
        }

        injectStyles() {
            const css = `
                #ai-chat-widget {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    z-index: 99999;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
                }

                #ai-chat-button {
                    width: 60px;
                    height: 60px;
                    border-radius: 50%;
                    background: #2563eb;
                    border: none;
                    cursor: pointer;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                    transition: transform 0.2s ease;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }

                #ai-chat-button:hover {
                    transform: scale(1.05);
                }

                #ai-chat-window {
                    display: none;
                    position: fixed;
                    bottom: 90px;
                    right: 20px;
                    width: 350px;
                    height: 400px;
                    background: white;
                    border-radius: 16px;
                    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
                    flex-direction: column;
                    overflow: hidden;
                }

                .ai-chat-header {
                    padding: 20px;
                    background: #2563eb;
                    color: white;
                    font-weight: 600;
                    font-size: 16px;
                }

                .ai-chat-messages {
                    flex: 1;
                    overflow-y: auto;
                    padding: 20px;
                    display: flex;
                    flex-direction: column;
                    gap: 12px;
                    background: #f8fafc;
                }

                .ai-chat-input {
                    padding: 16px;
                    border-top: 1px solid #e2e8f0;
                    display: flex;
                    background: white;
                }

                .ai-chat-input input {
                    flex: 1;
                    padding: 12px;
                    border: 1px solid #e2e8f0;
                    border-radius: 8px;
                    margin-right: 8px;
                    font-size: 16px;
                    outline: none;
                    transition: border-color 0.2s ease;
                    -webkit-text-size-adjust: 100%;
                }

                .ai-chat-input input:focus {
                    border-color: #2563eb;
                }

                .ai-chat-input button {
                    padding: 8px 16px;
                    background: #2563eb;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: 500;
                    transition: background 0.2s ease;
                }

                .ai-chat-input button:hover {
                    background: #1d4ed8;
                }

                .ai-message {
                    padding: 12px 16px;
                    border-radius: 12px;
                    max-width: 85%;
                    line-height: 1.5;
                    font-size: 14px;
                    white-space: pre-wrap;
                    word-wrap: break-word;
                }

                .ai-message.user {
                    background: #2563eb;
                    color: white;
                    margin-left: auto;
                    border-bottom-right-radius: 4px;
                }

                .ai-message.bot {
                    background: white;
                    color: #1f2937;
                    margin-right: auto;
                    border-bottom-left-radius: 4px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
                }

                .ai-chat-messages::-webkit-scrollbar {
                    width: 6px;
                }

                .ai-chat-messages::-webkit-scrollbar-track {
                    background: transparent;
                }

                .ai-chat-messages::-webkit-scrollbar-thumb {
                    background: #cbd5e1;
                    border-radius: 3px;
                }

                .ai-message.loading {
                    display: flex;
                    align-items: center;
                    gap: 4px;
                }

                .ai-message.loading span {
                    width: 8px;
                    height: 8px;
                    background: #94a3b8;
                    border-radius: 50%;
                    display: inline-block;
                    animation: bounce 1.4s infinite ease-in-out both;
                }

                .ai-message.loading span:nth-child(1) { animation-delay: -0.32s; }
                .ai-message.loading span:nth-child(2) { animation-delay: -0.16s; }

                @keyframes bounce {
                    0%, 80%, 100% { transform: scale(0); }
                    40% { transform: scale(1.0); }
                }

                .ai-message p {
                    margin: 0 0 10px 0;
                }

                .ai-message p:last-child {
                    margin-bottom: 0;
                }

                .ai-message pre {
                    background: #f1f5f9;
                    padding: 10px;
                    border-radius: 6px;
                    overflow-x: auto;
                    margin: 8px 0;
                }

                .ai-message code {
                    font-family: monospace;
                    background: #f1f5f9;
                    padding: 2px 4px;
                    border-radius: 4px;
                    font-size: 0.9em;
                }

                .ai-message ul, .ai-message ol {
                    margin: 8px 0;
                    padding-left: 20px;
                }

                .ai-message li {
                    margin: 4px 0;
                }

                @media (max-width: 767px) {
                    #ai-chat-window {
                        width: 90%;
                        height: 50vh;
                        bottom: 90px;
                        right: 5%;
                    }

                    .ai-chat-input {
                        padding: 12px;
                    }

                    .ai-chat-input input {
                        font-size: 16px;
                        -webkit-text-size-adjust: 100%;
                    }
                }
            `;
            const style = document.createElement('style');
            style.textContent = css;
            document.head.appendChild(style);
        }

        createWidget() {
            const widget = document.createElement('div');
            widget.id = 'ai-chat-widget';
            
            widget.innerHTML = `
                <div id="ai-chat-window">
                    <div class="ai-chat-header">ご質問はこちら</div>
                    <div class="ai-chat-messages"></div>
                    <div class="ai-chat-input">
                        <input type="text" placeholder="メッセージを入力してください...">
                        <button>送信</button>
                    </div>
                </div>
                <button id="ai-chat-button">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                    </svg>
                </button>
            `;
            
            document.body.appendChild(widget);
        }

        addEventListeners() {
            const button = document.getElementById('ai-chat-button');
            const window = document.getElementById('ai-chat-window');
            const input = window.querySelector('input');
            const sendButton = window.querySelector('button');

            button.addEventListener('click', () => {
                window.style.display = (window.style.display === 'none' || window.style.display === '') ? 'flex' : 'none';
            });

            const sendMessage = () => {
                const message = input.value.trim();
                if (message) {
                    this.sendMessage(message);
                    input.value = '';
                }
            };

            sendButton.addEventListener('click', sendMessage);
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') sendMessage();
            });
        }

        formatMessage(text) {
            let formatted = text.split('\n').map(line => line.trim()).filter(line => line).map(line => `<p>${line}</p>`).join('');
            formatted = formatted.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
            formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');
            formatted = formatted.replace(/^\s*[-*]\s+(.+)/gm, '<li>$1</li>');
            formatted = formatted.replace(/(<li>.*?<\/li>\s*)+/g, '<ul>$&</ul>');
            return formatted;
        }

        addMessageToChat(message, isUser) {
            const messagesDiv = document.querySelector('.ai-chat-messages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `ai-message ${isUser ? 'user' : 'bot'}`;
            
            if (isUser) {
                messageDiv.textContent = message;
            } else {
                messageDiv.innerHTML = this.formatMessage(message);
            }
            
            messagesDiv.appendChild(messageDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }

        async sendMessage(message) {
            this.addMessageToChat(message, true);

            const loadingDiv = document.createElement('div');
            loadingDiv.className = 'ai-message bot loading';
            loadingDiv.innerHTML = '<span></span><span></span><span></span>';
            
            const messagesDiv = document.querySelector('.ai-chat-messages');
            messagesDiv.appendChild(loadingDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;

            try {
                const response = await fetch(this.apiEndpoint, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Chatbot-Token': this.token
                    },
                    body: JSON.stringify({
                        message,
                        conversation_id: this.conversationId
                    })
                });

                const data = await response.json();
                loadingDiv.remove();
                
                if (data.error) throw new Error(data.error);
                this.addMessageToChat(data.response, false);
            } catch (error) {
                loadingDiv.remove();
                console.error('Chat error:', error);
                this.addMessageToChat('Sorry, I encountered an error. Please try again later.', false);
            }
        }
    }

    new AIChatbot();
})();